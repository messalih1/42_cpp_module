#include "Bureaucrat.hpp"
#include "Form.hpp"

 
int main()
{
    try
    {
        Bureaucrat b;
        Bureaucrat c;

        c = b;

        // Form form("no",200,200);
        // // form.beSigned(b);
        // std::cout << form;
    }   
    catch(std::exception & e)// because what() in class exception
    {
        std::cout << e.what() << std::endl;
    }

}